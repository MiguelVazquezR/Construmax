<template>
    <div class="animate-pulse h-[80%]">
        <div class="flex items-center justify-between mx-12 mt-20">
            <div class="flex">
                <div class="h-8 w-[300px] bg-gray-200 rounded-full mr-5"></div>
                <div class="h-8 w-8 bg-gray-200 rounded-full mr-1"></div>
                <div class="h-8 w-8 bg-gray-200 rounded-full mr-1"></div>
                <div class="h-8 w-8 bg-gray-200 rounded-full"></div>
            </div>
            <div class="flex justify-end">
                <div class="h-7 w-32 bg-gray-200 rounded-full mr-5"></div>
                <div class="h-7 w-7 bg-gray-200 rounded-full mr-1"></div>
            </div>
        </div>
        <div class="mt-12 mx-auto h-5 w-1/6 bg-gray-300 rounded-full"></div>
        <div class="mt-8 h-px bg-gray-200"></div>
        <div class="mt-8 h-px bg-gray-200"></div>
        <div class="grid grid-cols-2 relative h-2/3">
            <div class="grid grid-cols-2 gap-3 ml-4 self-start">
                <div class="col-span-full mt-6 h-5 w-1/4 bg-gray-300 rounded-full"></div>
                <div class="h-5 w-1/6 bg-gray-200 rounded-full"></div>
                <div class="h-5 w-1/2 bg-gray-200 rounded-full"></div>
                <div class="h-5 w-1/6 bg-gray-200 rounded-full"></div>
                <div class="h-5 w-1/2 bg-gray-200 rounded-full"></div>
                <div class="h-5 w-1/6 bg-gray-200 rounded-full"></div>
                <div class="h-5 w-1/2 bg-gray-200 rounded-full"></div>
                <div class="h-5 w-1/6 bg-gray-200 rounded-full"></div>
                <div class="h-5 w-1/2 bg-gray-200 rounded-full"></div>
            </div>
            <div class="grid grid-cols-2 gap-3 ml-4 self-start">
                <div class="col-span-full mt-6 h-5 w-1/4 bg-gray-300 rounded-full"></div>
                <div class="h-5 w-1/6 bg-gray-200 rounded-full"></div>
                <div class="h-5 w-1/2 bg-gray-200 rounded-full"></div>
                <div class="h-5 w-1/6 bg-gray-200 rounded-full"></div>
                <div class="h-5 w-1/2 bg-gray-200 rounded-full"></div>
                <div class="h-5 w-1/6 bg-gray-200 rounded-full"></div>
                <div class="h-5 w-1/2 bg-gray-200 rounded-full"></div>
                <div class="h-5 w-1/6 bg-gray-200 rounded-full"></div>
                <div class="h-5 w-1/2 bg-gray-200 rounded-full"></div>
            </div>
            <div class="mx-auto w-px h-full bg-gray-200 absolute top-0 left-1/2"></div>
        </div>

    </div>
</template>
<script>
export default {

}
</script>