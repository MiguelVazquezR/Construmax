<template>
    <figure>
        <img src="../../../public/images/construmax_logo.png" alt="logo">
    </figure>
</template>
