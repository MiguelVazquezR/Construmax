<script setup>
import { Link } from '@inertiajs/vue3';
</script>

<template>
    <Link :href="'/'">
        <figure>
            <img src="../../../public/images/construmax_logo.png" alt="logo">
        </figure>
    </Link>
</template>
