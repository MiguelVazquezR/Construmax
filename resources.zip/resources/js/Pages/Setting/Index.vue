<template>
    <AppLayout title="Configuraciones">
        
     </AppLayout>
 </template>
 <script>
 import AppLayout from '@/Layouts/AppLayout.vue';
 
 export default {
     components: {
         AppLayout,
     }
 }
 </script>